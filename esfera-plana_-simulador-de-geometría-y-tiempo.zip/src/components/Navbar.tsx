import { motion } from 'motion/react';
import { Circle, Ruler, Disc, Box, Dumbbell, MonitorPlay } from 'lucide-react';

const tabs = [
  { id: 'conceptos', label: 'Conceptos', icon: Circle },
  { id: 'elementos', label: 'Elementos', icon: Disc },
  { id: 'perimetro', label: 'Perímetro', icon: Ruler },
  { id: 'area', label: 'Área', icon: Box },
  { id: 'ejercicios', label: 'Ejercicios', icon: Dumbbell },
  { id: 'resolucion', label: 'La Ilusión (3D)', icon: MonitorPlay },
];

interface NavbarProps {
  activeTab: string;
  setActiveTab: (id: string) => void;
}

export function Navbar({ activeTab, setActiveTab }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 bg-neutral-900/80 backdrop-blur-xl border-b border-neutral-800 p-4">
      <div className="max-w-7xl mx-auto">
        <ul className="flex flex-wrap items-center justify-center gap-2 sm:gap-4">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <li key={tab.id} className="relative">
                <button
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    isActive ? 'text-white' : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                  {isActive && (
                    <motion.div
                      layoutId="active-tab"
                      className="absolute inset-0 bg-pink-500/20 border border-pink-500/50 rounded-full"
                      initial={false}
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}

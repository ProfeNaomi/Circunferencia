import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

export function Perimetro() {
  const [isPlaying, setIsPlaying] = useState(false);
  
  // r = 15. PI*d = 30 * PI ≈ 94.24
  const radius = 15;
  const circumference = 2 * Math.PI * radius;

  // We want to loop the animation if played
  useEffect(() => {
    if (isPlaying) {
      const timer = setTimeout(() => setIsPlaying(false), 5000); // Reset after 5s
      return () => clearTimeout(timer);
    }
  }, [isPlaying]);

  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-5xl mx-auto p-8 w-full flex-grow flex flex-col justify-center"
    >
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          El <span className="text-emerald-400">Perímetro</span> (Circunferencia)
        </h1>
        <p className="text-xl text-neutral-400 max-w-2xl mx-auto">
          Es la longitud del borde. Si "desenrollaras" el círculo, obtendrías una línea recta.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center">
        {/* Visualizer */}
        <div className="relative aspect-video w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-8 flex flex-col justify-center items-center shadow-2xl overflow-hidden">
          
          <svg viewBox="0 0 150 50" className="w-full h-full overflow-visible">
            {/* Ground line */}
            <line x1="10" y1="40" x2="140" y2="40" stroke="#333" strokeWidth="0.5" />
            
            {/* The unwrapped line - grows as the circle rolls */}
            <motion.line 
              x1="20" y1="40" 
              x2="20" y2="40"
              stroke="#10b981" strokeWidth="2"
              animate={{ 
                x2: isPlaying ? 20 + circumference : 20
              }}
              transition={{ duration: 4, ease: "linear" }}
            />

            {/* The rolling Circle */}
            <motion.g
              animate={{ 
                x: isPlaying ? circumference : 0,
                rotate: isPlaying ? 360 : 0
              }}
              transition={{ duration: 4, ease: "linear" }}
              style={{ originX: '20px', originY: `${40 - radius}px` }} // Rotate around its center
            >
              {/* Actual circle */}
              <circle cx="20" cy={40 - radius} r={radius} fill="none" stroke="#6366f1" strokeWidth="1.5" />
              {/* Spoke to see rotation */}
              <line x1="20" y1={40 - radius} x2="20" y2="40" stroke="#ec4899" strokeWidth="1" />
              <circle cx="20" cy="40" r="1.5" fill="#ec4899" />
            </motion.g>

            {/* Path tracking the total distance (faint) */}
            <line x1="20" y1="42" x2={20 + circumference} y2="42" stroke="#444" strokeWidth="0.5" strokeDasharray="1 1" />
            <text x={20 + circumference/2} y="47" fontSize="4" fill="#888" textAnchor="middle">2 × π × r</text>
          </svg>

          <button 
            onClick={() => setIsPlaying(true)}
            disabled={isPlaying}
            className="absolute bottom-6 px-8 py-3 bg-emerald-500 hover:bg-emerald-400 disabled:bg-neutral-800 disabled:text-neutral-500 text-neutral-950 font-bold rounded-xl transition-colors"
          >
            {isPlaying ? 'Desenrollando...' : 'Desenrollar Círculo'}
          </button>
        </div>

        {/* Info */}
        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-2xl">
            <h3 className="text-lg text-neutral-400 mb-2 uppercase tracking-widest font-bold">Fórmula</h3>
            <div className="text-5xl font-mono text-white mb-4">
              P = 2 · π · r
            </div>
            <div className="text-3xl font-mono text-neutral-500 mb-6">
              P = π · d
            </div>
            
            <ul className="space-y-4 text-neutral-300">
              <li className="flex gap-4">
                <span className="font-bold text-pink-400">r</span>
                <span>El <strong>Radio</strong> (distancia del centro al borde).</span>
              </li>
              <li className="flex gap-4">
                <span className="font-bold text-indigo-400">d</span>
                <span>El <strong>Diámetro</strong> (doble del radio).</span>
              </li>
              <li className="flex gap-4">
                <span className="font-bold text-emerald-400">π</span>
                <span><strong>Pi</strong> (~3.14159...). Es la cantidad de veces que el diámetro cabe en el perímetro.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </motion.section>
  );
}
